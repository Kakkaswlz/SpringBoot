package com.devsenai1a.conversor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversorApplicationTests {

	@Test
	void contextLoads() {
	}

}
