package com.devsenai1a.conversor.controllers;

import java.util.Map;
import java.util.HashMap;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConversorController {
	
	@GetMapping("/kelvin-grau")
	public double KelvinGrau(@RequestParam double a) {
		return a - 273.15 ;
	}
	
	@GetMapping("/kelvin-fahrenheit")
	public double KelvinFahrenheit(@RequestParam double a) {
		return (a - 273.15) * 1.8 + 32 ;
	}
	
	@GetMapping("/grau-kelvin")
	public double GrauKelvin(@RequestParam double a) {
		return a + 273.15 ;
	}
	
	@GetMapping("/grau-fahrenheit")
	public double GrauFahrenheit(@RequestParam double a) {
		return (a * 1.8) + 32 ;
	}
	
	@GetMapping("/fahrenheit-celsius")
	public double FahrenheitCelsius(@RequestParam double a) {
		return (a - 32) * 5/9;
	}
	
	@GetMapping("/fahrenheit-kelvin")
	public double FahrenheitKelvin(@RequestParam double a) {
		return (a - 32) * 5/9 + 273.15;
	}
	
	@PostMapping("/calcular")
	@ResponseBody
	public Map<String, Object> calcularJson(
			@RequestParam double num1,
			@RequestParam String convertor,
			@RequestParam String conversao){
		
		double resultado = 0;
		String erro = null;
		
		switch(conversao) {
	    case "kelvin": 
	        if(convertor.equals("celsius")) {
	            resultado = num1 - 273.15;
	        } else if(convertor.equals("fahrenheit")) {
	            resultado = (num1 - 273.15) * 1.8 + 32;
	        }
	        break;
	        
	    case "celsius":
	        if(convertor.equals("kelvin")) {
	            resultado = num1 + 273.15;
	        } else if(convertor.equals("fahrenheit")) {
	            resultado = (num1 * 1.8) + 32;
	        }
	        break;
	        
	    case "fahrenheit":
	        if(convertor.equals("celsius")) {
	            resultado = (num1 - 32) * 5/9;
	        } else if(convertor.equals("kelvin")) {
	            resultado = (num1 - 32) * 5/9 + 273.15;
	        }
	        break;
			
			
		default: erro = "Operação Inválida"; break;
		}
		Map<String, Object> resp = new HashMap<>();
		resp.put("resultado", resultado);
		resp.put("erro", erro);
		return resp;
	}

}
